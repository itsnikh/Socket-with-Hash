#include<stdio.h>	
#include<unistd.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<fcntl.h>
#include<stdlib.h>
#include<time.h>
#include<errno.h>


#define TEXT "SERVER"
#define CLEAR ccc()
#define SIZE 1024
#define PORT 5000
#define TCP 48
#define UDP 49

struct hash
{	
	unsigned short port;
	unsigned char ip[16];
	unsigned char time[30];
	unsigned short count;
	unsigned char data[50];
	unsigned short protocol;
	struct hash *next;

}*h[65536];

void ccc(void)
{
	printf("\033[H\033[J");

}

unsigned short hash(unsigned char *ip)
{
	unsigned short i;
	unsigned short sum=0;

	for(i=0;*(ip+i)!='\0';i++)
	   if (*(ip+i)>='0' && *(ip+i)<='9')
		sum= sum + (unsigned short)( *(ip+i) - 48);
	   else if ( *(ip+i)=='.' )
		continue;
	   else 
		*(ip + i--)='\0';

	return (sum % 65536) ;
}

void insert(unsigned char ip[16], unsigned short port, unsigned char htime[], unsigned short protocol, unsigned char buf[])
{
	unsigned char index;
	unsigned char c;
	unsigned char i;
	unsigned char cmp;
	struct hash *temp;
	index= hash(ip);

	if(h[index]==NULL)
	{
		h[index] = (struct hash *) malloc( sizeof(struct hash) );

		if(h[index]==NULL)
		{
			printf("initial malloc fail...exiting");
			exit(-1);
		}
		
		temp = h[index];

		if(protocol == TCP)
		   temp->protocol = TCP;
		else if(protocol == UDP)
		   temp->protocol = UDP;
		else
		{
			printf("\n\nWrong Protocol...Exiting!!");
			exit(-1);
		}

		for(c=0;ip[c]!='\0';c++)
	   	   temp->ip[c]=ip[c];
		temp->ip[c]='\0';

		temp->port=port;

		for(c=0;htime[c]!='\0';c++)	
		   temp->time[c]=htime[c];

		++(temp->count);

temp->next=NULL;

		for(i=0;buf[i]!='\0';i++)
		   temp->data[i]=buf[i];
		   temp->data[i]='\0';

		
	}

	else
	{
	  temp = h[index];

	  while(temp)
	  {
		if((cmp = strcmp(temp->ip,ip))==0 && temp->protocol == protocol)
		{
			for(c=0;htime[c]!='\0';c++)	
		  	 temp->time[c]=htime[c];

			++(temp->count);
			temp->port=port;

			for(i=0;buf[i]!='\0';i++)
			   temp->data[i]=buf[i];
			   temp->data[i]='\0';

			return;

		}
		
		else if(temp->next==NULL)
			break;

		else 
		temp=temp->next;

	  } // end of while

		if(temp->next==NULL ) 
		{
			temp->next = (struct hash *) malloc( sizeof(struct hash) );

			if(temp->next ==NULL)
			{
				printf("NEW Malloc fail...exiting");
				exit(-1);
			}		

			temp=temp->next;

			
			if(protocol == TCP)
			   temp->protocol = TCP;
			else if(protocol == UDP)
			   temp->protocol = UDP;
			else
			{
				printf("\n\nWrong Protocol...Exiting!!");
				exit(-1);
			}

			for(c=0;ip[c]!='\0';c++)
		   	   temp->ip[c]=ip[c];

			temp->ip[c]='\0';
			temp->port=port;

			++(temp->count);

			for(c=0;htime[c]!='\0';c++)	
		  	 temp->time[c]=htime[c];

			temp->next=NULL;
			

			for(i=0;buf[i]!='\0';i++)
			   temp->data[i]=buf[i];
			   temp->data[i]='\0';
		}	//end of if

	}	//end of else 
}

void delete(unsigned char ip[], unsigned short protocol)
{
	unsigned char index;
	unsigned char flag=0;
	struct hash *temp, *prev;
	
	index= hash(ip);
	temp=h[index];
	prev=temp;
	if(temp==NULL)
     	   printf( "cannot delete...Entry not present\n" );
	else
	{
	   while(temp!=NULL)
	   {		
		if(strcmp(temp->ip,ip)==0 && temp->protocol == protocol)
		{
			prev->next = temp->next;
			if(h[index] == temp)
			h[index] = temp->next;
			temp = memset(temp, '\0', sizeof(struct hash));
			if(h[index] == temp)
			h[index] = temp->next;
			free(temp);
			temp=NULL;
			flag=1;
			break;
		}	
		else 
		{
			prev=temp;
			temp=temp->next;
		} // end of else 
	   }//end of while
	}//end of else 

	if(flag==1)
	printf("\nENTRY DELETED\n");
	else if(flag==0)
	printf("\nENTRY NOT FOUND...CANNOT DELETE IT!!\n");


}

void display()
{
	unsigned short c;
	unsigned short count;
	unsigned char flag=0;
	struct hash *temp;

	for(c=0;c<65535;c++)
	   if(h[c]!=NULL)
		flag=1;
	
	if(flag==0) printf( "Cannot DISPLAY...Entry not present\n" );
	else
	{
	printf("\n\n\t\t-----HASH TABLE-----");
	printf("\n\n");
	for(c=0;c<65535;c++)
	{
	   	count=0;
		temp=h[c];
	   	
	   	if(temp==NULL)
	     	   continue;
	   	else
	   	{
		   printf("\n\nINDEX (%02hd) ", c);
		   while(temp!=NULL)
		   {		
			if(temp->protocol == TCP)
			printf("\n\nIP ADDR.: %s:%5d \n    TIME: %sPROTOCOL: TCP\n    DATA: %s\n   COUNT: %hd \n", temp->ip, temp->port, temp->time, temp->data, temp->count);
			else 
			printf("\n\nIP ADDR.: %s:%5d \n    TIME: %sPROTOCOL: UDP\n    DATA: %s\n   COUNT: %hd \n", temp->ip, temp->port, temp->time, temp->data, temp->count);
			temp=temp->next;
		   }

	   	}//end of else 	     

	} // end of for loop
}
}

void main(void)
{
	struct sockaddr_in s,c;
	unsigned short tcp;
	unsigned short udp;
	unsigned short cfd;
	unsigned short client_socket[30] , max_clients = 30 ;
	unsigned short sd, max_sd;
	unsigned short activity, i;
	unsigned char buf[SIZE], *temp=TEXT, *htime;
	unsigned char c_name[INET_ADDRSTRLEN];
	unsigned char s_name[INET_ADDRSTRLEN];
	time_t current_time;
	fd_set fds;
	socklen_t len= sizeof(c);

	if((tcp=socket(AF_INET,SOCK_STREAM,0))==0)
	{
		printf("Error in create TCP Socket\n\n");
		exit(EXIT_FAILURE);
	}

	if((udp=socket(AF_INET,SOCK_DGRAM,0))==0)
	{
		printf("Error in create UDP Socket\n\n");
		exit(EXIT_FAILURE);
	}	

	s.sin_family=AF_INET;
	s.sin_addr.s_addr=INADDR_ANY;
	s.sin_port=htons(PORT);

	if((bind(tcp,(struct sockaddr *)&s, sizeof(s)))<0)
	{
		printf("Error in TCP Bind\n\n");
		exit(EXIT_FAILURE);
	}

	if((bind(udp,(struct sockaddr *)&s, sizeof(s)))<0)
	{
		printf("Error in UDP Bind\n\n");
		exit(EXIT_FAILURE);
	}

	if((listen(tcp,5))<0)
	{
		printf("\nError in Server Listen\n\n");
		exit(EXIT_FAILURE);
	}

	printf("\nWaiting for connections..!!\n");		

	while(1)
	{
		FD_ZERO(&fds);
		FD_SET(tcp,&fds);
		FD_SET(udp,&fds);		

		//add child sockets to set
       		for ( i = 0 ; i < max_clients ; i++) 
        	{

			sd = client_socket[i];
			if(sd > 0)
			FD_SET( sd , &fds);
			if(sd > max_sd)
			max_sd = sd;
		}

		activity = select( max_sd + 1 , &fds , NULL , NULL , NULL);
		if ((activity < 0) && (errno!=EINTR))  
		{  
			printf("select error");  
		}
		
		if(FD_ISSET(tcp,&fds))
		{
			if((cfd=accept(tcp,(struct sockaddr *)&c, &len))<0)
			{
				printf("ERROR in Accept!!\n\n");
				exit(-1);
			}
			
			read(cfd, buf, SIZE);

			inet_ntop(AF_INET,&c.sin_addr.s_addr, c_name,sizeof(c_name));

			if( ((strcmp(buf,"exit"))==0) || ((strcmp(buf,"EXIT"))==0) )  // ((cmp = strcmp(temp->ip,ip))==0)
			{
				printf("\n\nClosing the Server!!\n\n");
				sleep(2);
				exit(0);
			}

			else if( strcmp(buf,"delete")==0 || strcmp(buf,"DELETE")==0 )
			{
				CLEAR;
				printf("\n\nDELETING the IP ENTRY!!");
				delete(c_name, TCP);
				//CLEAR;
				display();
			}

			else
			{
				CLEAR;		//function to clear screen
				time(&current_time);
				htime=ctime(&current_time);
				insert(c_name, ntohs(c.sin_port), htime, TCP, buf);
				display();
			}
		}// End of IF

		else if(FD_ISSET(udp,&fds))
		{
			if((recvfrom(udp, buf, sizeof(buf), 0, (struct sockaddr *)&c, &len))<0)
				printf("\n\nError reading data!!");

			inet_ntop(AF_INET,&c.sin_addr.s_addr, c_name,sizeof(c_name));

			if( ((strcmp(buf,"exit"))==0) || ((strcmp(buf,"EXIT"))==0) )
			{
				printf("\n\nClosing the Server!!\n\n");
				sleep(2);
				exit(0);
			}


			else if( strcmp(buf,"delete")==0 || strcmp(buf,"DELETE")==0 )
			{
				CLEAR;
				printf("\n\nDELETING the IP ENTRY!!");
				delete(c_name, UDP);
				display();
			}

			else
			{
				CLEAR;		//function to clear screen			
				time(&current_time);
				htime=ctime(&current_time);
				insert(c_name, ntohs(c.sin_port), htime, UDP, buf);
				display();
			}
		}// End of ELSE IF 

close(cfd);		
	}	//End of while(1)
close(tcp);
close(udp);

}	//End of main()

